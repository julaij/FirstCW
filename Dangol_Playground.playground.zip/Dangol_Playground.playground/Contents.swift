import UIKit

var greeting = "Hello, playground"
print("Hello Moon")
var planet = "Mars"
print("My favourite planet is: "+planet)
print("My favourite palnet is: /(planet)")
var age = 23;
//print("My age is: "+age)
print("My age is: \(age)")
var weight = 45;
print("My weight is: \(weight)")
var color = "Green"
print(1, "Hello!", "Y", 78.9,terminator: "$")
print("Something!")
print("Hii",10,12.5)
var programmingLanguage = "Swift"
print("My favorite programming language is \(programmingLanguage)")
print("""
Hello
World!
""")
print("Hello All, \rWelcome to Swift programming")
let welcomeMessage : String = "Hello!"
print(welcomeMessage , "All")
print("Welcome to Swift Programming")
print("Fall 2021")
print("**********")
print("Welcome to Swift Programming" , terminator : "-")
print("Fall 2021")
print("The list of numbers are")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")




